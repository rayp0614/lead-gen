
import { GoogleGenAI, Type } from "@google/genai";
import { UploadedFile, AnalysisResult } from "../types";

export const analyzeOrganization = async (
  files: UploadedFile[],
  websiteUrl: string,
  deepResearch: boolean,
  qualityFile: UploadedFile | null,
  apiKey?: string
): Promise<AnalysisResult> => {
  const key = apiKey || process.env.API_KEY || '';
  if (!key) {
    throw new Error('API key is required. Please enter your Gemini API key in the settings.');
  }
  const ai = new GoogleGenAI({ apiKey: key });

  const parts = files.map(file => ({
    inlineData: {
      data: file.base64.split(',')[1],
      mimeType: file.type
    }
  }));

  if (qualityFile) {
    parts.push({
      inlineData: {
        data: qualityFile.base64.split(',')[1],
        mimeType: qualityFile.type
      }
    });
  }

  const prompt = `
    ACT AS: Expert Business Development Analyst and Private Sector Researcher.
    
    OBJECTIVE:
    Generate a comprehensive "Executive Lead Generation Dossier" for the organization.
    
    CRITICAL INSTRUCTION FOR FINANCIALS (ELIMINATE "N/A"):
    - You MUST provide a 5-year history (2023, 2022, 2021, 2020, 2019).
    - For EVERY year, you MUST provide:
        1. Total Revenue (Part I, Line 12)
        2. Total Expenses (Part I, Line 18)
        3. Net Income (Calculated: Revenue - Expenses)
        4. Total Assets (Part X, Line 16)
        5. Net Assets (Part X, Line 33)
    
    SEARCH PROTOCOL FOR MISSING DATA:
    - If any of the above 5 fields are "N/A" or missing for 2019, 2020, or 2021 after reading the uploaded files:
        1. Use googleSearch to find "[Organization Name] ProPublica Nonprofit Explorer" or "[Organization Name] Guidestar".
        2. Specifically search for "Form 990 [Organization Name] [Year]" to find the PDF or summary page.
        3. ProPublica usually lists multi-year trends; prioritize this source to fill the gaps for 2019-2021.
    - DATA INTEGRITY: You are FORBIDDEN from returning "N/A" for these financial fields unless the organization did not exist. If you find Total Revenue and Total Expenses but not Net Income, CALCULATE it.
    - If you find Revenue from a 'Prior Year' column in a 990, look immediately to the right for Expenses and Net Assets in that same column.

    ${deepResearch ? `
    DEEP RESEARCH INSTRUCTIONS:
    - Perform an exhaustive web search for the organization: "${websiteUrl}".
    - Find recent news articles (last 24 months).
    - Analyze public sentiment (Glassdoor reviews, social media mentions, local news).
    - Identify community reputation and strategic context (major partnerships, recent expansions, or leadership scandals).

    CRITICAL - ENTITY VERIFICATION:
    - ONLY include news/information that EXACTLY matches the organization name from the uploaded documents.
    - If the org is "MARCH Inc", do NOT include results for "MARC Inc", "March Foundation", or similar names.
    - Verify the EIN, state, or city matches before including any web search results.
    - If you cannot find verified news for this EXACT organization, return "No verified news found for this organization" rather than guessing.
    - When in doubt, EXCLUDE the result rather than risk mixing up similar-named organizations.
    ` : ''}
    
    INSTRUCTIONS FOR QUALITY REPORT ANALYSIS:
    - Analyze the provided Quality Service Review (QSR) PDF.
    - Extract the "FOCUS AREA" table: Description and Percent Met.
    - Categorize status: 'low' (<80%), 'medium' (80-89%), 'high' (>=90%).
    
    TASKS:
    1. BUDGET SCAN & 5-YEAR FINANCIAL TREND (Strictly no N/A).
    2. QUALITY SCORECARD (Full table extraction).
    3. SERVICE IDENTIFICATION (DDS Service Types).
    4. ${deepResearch ? 'QUALITATIVE DEEP RESEARCH (Sentiments, News, Reputation).' : 'BASIC STRATEGIC OVERVIEW.'}
    5. STRATEGIC DOSSIER (Pain Points, Decision Maker, Cold Outreach).
       
    DATA SOURCES:
    - Uploaded Files (990s, QSR PDF).
    - Web Search (Google Search Tool).
    - Website: ${websiteUrl}

    Return the analysis in a strictly formatted JSON structure.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: { parts: [...parts, { text: prompt }] },
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      // Increased reasoning capability to handle the financial gaps
      thinkingConfig: { thinkingBudget: 4000 },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          targetName: { type: Type.STRING },
          id: { type: Type.STRING },
          financialHealth: {
            type: Type.OBJECT,
            properties: {
              revenue: { type: Type.STRING },
              netAssets: { type: Type.STRING },
              professionalFees: { type: Type.STRING },
              verdict: { type: Type.STRING },
              burnRate: { type: Type.STRING },
              runway: { type: Type.STRING },
            },
            required: ["revenue", "netAssets", "professionalFees", "verdict", "burnRate", "runway"]
          },
          financialHistory: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                year: { type: Type.STRING },
                revenue: { type: Type.STRING },
                expenses: { type: Type.STRING },
                netIncome: { type: Type.STRING },
                assets: { type: Type.STRING },
                netAssets: { type: Type.STRING },
                liabilities: { type: Type.STRING },
              },
              required: ["year", "revenue", "expenses", "netIncome", "assets", "netAssets", "liabilities"]
            }
          },
          deepResearchData: {
            type: Type.OBJECT,
            properties: {
              sentiment: { type: Type.STRING },
              recentNews: { type: Type.ARRAY, items: { type: Type.STRING } },
              reputation: { type: Type.STRING },
              strategicContext: { type: Type.STRING },
            },
            required: ["sentiment", "recentNews", "reputation", "strategicContext"]
          },
          qualityAssessment: {
            type: Type.OBJECT,
            properties: {
              rating: { type: Type.STRING },
              summary: { type: Type.STRING },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              concerns: { type: Type.ARRAY, items: { type: Type.STRING } },
              allFocusAreas: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    description: { type: Type.STRING },
                    percentMet: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ['low', 'medium', 'high'] }
                  },
                  required: ["description", "percentMet", "status"]
                }
              }
            },
            required: ["rating", "summary", "strengths", "concerns", "allFocusAreas"]
          },
          serviceSummary: { type: Type.STRING },
          serviceTypes: { type: Type.ARRAY, items: { type: Type.STRING } },
          painPoints: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                symptom: { type: Type.STRING },
                evidence: { type: Type.STRING },
                pitch: { type: Type.STRING },
              },
              required: ["symptom", "evidence", "pitch"]
            }
          },
          decisionMaker: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              role: { type: Type.STRING },
              why: { type: Type.STRING },
            },
            required: ["name", "role", "why"]
          },
          coldEmailHook: { type: Type.STRING },
          rawAnalysis: { type: Type.STRING }
        },
        required: ["targetName", "financialHealth", "financialHistory", "qualityAssessment", "serviceSummary", "serviceTypes", "painPoints", "decisionMaker", "coldEmailHook", "rawAnalysis"]
      }
    }
  });

  try {
    const result: AnalysisResult = JSON.parse(response.text || '{}');
    result.id = result.id || crypto.randomUUID();
    result.timestamp = Date.now();
    return result;
  } catch (err) {
    console.error("Failed to parse analysis result", err);
    throw new Error("Analysis parsing failed. Please ensure the uploaded PDFs are readable.");
  }
};
