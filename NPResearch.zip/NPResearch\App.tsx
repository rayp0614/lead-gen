
import React, { useState, useEffect } from 'react';
import { UploadedFile, AnalysisResult, AnalysisStatus } from './types';
import { analyzeOrganization } from './services/geminiService';
import AnalysisDisplay from './components/AnalysisDisplay';
import LeadList from './components/LeadList';

// File validation constants
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_FILE_TYPES = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp'];

const validateFile = (file: File): string | null => {
  if (file.size > MAX_FILE_SIZE) {
    return `File "${file.name}" exceeds 10MB limit (${(file.size / 1024 / 1024).toFixed(1)}MB)`;
  }
  if (!ALLOWED_FILE_TYPES.includes(file.type)) {
    return `File "${file.name}" has unsupported type "${file.type}". Allowed: PDF, PNG, JPEG`;
  }
  return null;
};

const App: React.FC = () => {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [qualityFile, setQualityFile] = useState<UploadedFile | null>(null);
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [urlError, setUrlError] = useState<string | null>(null);
  const [deepResearch, setDeepResearch] = useState(false);
  const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.IDLE);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savedLeads, setSavedLeads] = useState<AnalysisResult[]>([]);
  const [showLeadList, setShowLeadList] = useState(false);
  const [apiKey, setApiKey] = useState<string>('');
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('saved_leads');
    if (stored) {
      try {
        setSavedLeads(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to load saved leads");
      }
    }
    // Load API key from localStorage
    const storedApiKey = localStorage.getItem('gemini_api_key');
    if (storedApiKey) {
      setApiKey(storedApiKey);
    }
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles: UploadedFile[] = [];
      for (let i = 0; i < e.target.files.length; i++) {
        const file = e.target.files[i];
        // Validate file before processing
        const validationError = validateFile(file);
        if (validationError) {
          setError(validationError);
          return;
        }
        const base64 = await fileToBase64(file);
        newFiles.push({
          name: file.name,
          type: file.type,
          base64
        });
      }
      setError(null); // Clear any previous errors
      setFiles(prev => [...prev, ...newFiles]);
    }
  };

  const handleQualityFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      // Validate file before processing
      const validationError = validateFile(file);
      if (validationError) {
        setError(validationError);
        return;
      }
      const base64 = await fileToBase64(file);
      setError(null); // Clear any previous errors
      setQualityFile({
        name: file.name,
        type: file.type,
        base64
      });
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const runAnalysis = async () => {
    if (files.length === 0) {
      setError("Please upload at least one financial document (Form 990).");
      return;
    }

    if (!apiKey) {
      setError("Please enter your Gemini API key in the settings (gear icon in the header).");
      return;
    }

    if (urlError) {
      setError("Please fix the website URL before running analysis.");
      return;
    }

    setStatus(AnalysisStatus.ANALYZING);
    setError(null);

    try {
      const analysisResult = await analyzeOrganization(files, websiteUrl, deepResearch, qualityFile, apiKey);
      setResult(analysisResult);
      setStatus(AnalysisStatus.COMPLETED);
    } catch (err) {
      const message = err instanceof Error
        ? err.message
        : "An unexpected error occurred during analysis.";
      setError(message);
      setStatus(AnalysisStatus.ERROR);
    }
  };

  const saveLead = (lead: AnalysisResult) => {
    const exists = savedLeads.find(l => l.targetName === lead.targetName);
    if (exists) {
      alert("This organization is already in your lead list.");
      return;
    }
    const updated = [lead, ...savedLeads];
    setSavedLeads(updated);
    localStorage.setItem('saved_leads', JSON.stringify(updated));
    alert("Saved to lead list!");
  };

  const removeLead = (id: string) => {
    const updated = savedLeads.filter(l => l.id !== id);
    setSavedLeads(updated);
    localStorage.setItem('saved_leads', JSON.stringify(updated));
  };

  const reset = () => {
    setFiles([]);
    setQualityFile(null);
    setWebsiteUrl('');
    setUrlError(null);
    setDeepResearch(false);
    setResult(null);
    setStatus(AnalysisStatus.IDLE);
    setError(null);
  };

  const saveApiKey = (key: string) => {
    setApiKey(key);
    if (key) {
      localStorage.setItem('gemini_api_key', key);
    } else {
      localStorage.removeItem('gemini_api_key');
    }
  };

  const isValidUrl = (url: string): boolean => {
    if (!url) return true; // Empty is OK
    try {
      const parsed = new URL(url);
      return ['http:', 'https:'].includes(parsed.protocol);
    } catch {
      return false;
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setWebsiteUrl(url);
    if (url && !isValidUrl(url)) {
      setUrlError('Please enter a valid URL starting with http:// or https://');
    } else {
      setUrlError(null);
    }
  };

  return (
    <div className="min-h-screen pb-20 bg-slate-50">
      <header className="bg-slate-900 text-white py-6 px-4 shadow-xl mb-8 sticky top-0 z-30">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <button
            type="button"
            className="flex items-center gap-4 cursor-pointer bg-transparent border-none"
            onClick={reset}
            aria-label="Reset and return to start"
          >
            <div className="bg-indigo-600 p-2 rounded-lg">
              <i className="fa-solid fa-file-invoice-dollar text-xl" aria-hidden="true"></i>
            </div>
            <h1 className="text-xl font-bold tracking-tight">Lead Gen Dossier</h1>
          </button>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowApiKeyInput(!showApiKeyInput)}
              className={`p-2 rounded-lg text-sm font-semibold transition-all border ${
                apiKey
                  ? 'bg-emerald-600/20 border-emerald-500/30 text-emerald-400 hover:bg-emerald-600/30'
                  : 'bg-amber-600/20 border-amber-500/30 text-amber-400 hover:bg-amber-600/30'
              }`}
              aria-label={apiKey ? 'API key configured - click to change' : 'Configure API key'}
              title={apiKey ? 'API key configured' : 'API key required'}
            >
              <i className={`fa-solid ${apiKey ? 'fa-key' : 'fa-gear'}`} aria-hidden="true"></i>
            </button>
            <button
              onClick={() => setShowLeadList(!showLeadList)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 border border-slate-700 relative"
              aria-expanded={showLeadList}
              aria-label={`${showLeadList ? 'Hide' : 'Show'} saved leads (${savedLeads.length} saved)`}
            >
              <i className="fa-solid fa-list-ul" aria-hidden="true"></i>
              My Leads
              {savedLeads.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-indigo-600 text-[10px] w-5 h-5 flex items-center justify-center rounded-full shadow-lg">
                  {savedLeads.length}
                </span>
              )}
            </button>
            {status === AnalysisStatus.COMPLETED && (
              <button 
                onClick={reset}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-sm font-semibold transition-colors"
              >
                New Analysis
              </button>
            )}
          </div>
        </div>
      </header>

      {/* API Key Settings Modal */}
      {showApiKeyInput && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setShowApiKeyInput(false)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <i className="fa-solid fa-key text-indigo-500" aria-hidden="true"></i>
                API Key Settings
              </h2>
              <button
                onClick={() => setShowApiKeyInput(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
                aria-label="Close settings"
              >
                <i className="fa-solid fa-xmark" aria-hidden="true"></i>
              </button>
            </div>
            <p className="text-sm text-slate-600 mb-4">
              Enter your Google Gemini API key to use the analysis features. Your key is stored locally in your browser and never sent to our servers.
            </p>
            <div className="space-y-4">
              <div>
                <label htmlFor="api-key-input" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Gemini API Key
                </label>
                <input
                  id="api-key-input"
                  type="password"
                  placeholder="Enter your API key..."
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-mono"
                  value={apiKey}
                  onChange={(e) => saveApiKey(e.target.value)}
                />
              </div>
              {apiKey && (
                <div className="flex items-center gap-2 text-emerald-600 text-sm">
                  <i className="fa-solid fa-circle-check" aria-hidden="true"></i>
                  <span>API key saved locally</span>
                </div>
              )}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                <p className="text-xs text-slate-500">
                  <strong className="text-slate-700">Don't have an API key?</strong><br />
                  Get one free from{' '}
                  <a
                    href="https://aistudio.google.com/app/apikey"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-600 hover:underline"
                  >
                    Google AI Studio
                  </a>
                </p>
              </div>
              <button
                onClick={() => setShowApiKeyInput(false)}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="max-w-6xl mx-auto px-4 relative">
        {showLeadList && (
          <div className="mb-12">
            <LeadList leads={savedLeads} onRemove={removeLead} onSelect={(lead) => { setResult(lead); setStatus(AnalysisStatus.COMPLETED); setShowLeadList(false); }} />
          </div>
        )}

        {(status === AnalysisStatus.IDLE || status === AnalysisStatus.ERROR) && !showLeadList ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in duration-500">
            <div className="space-y-6">
              <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2 text-slate-700">
                  <i className="fa-solid fa-cloud-arrow-up text-indigo-500"></i>
                  Financials & Profiles (PDFs)
                </h2>
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-6 text-center hover:border-indigo-400 transition-colors group relative">
                  <input type="file" multiple accept="application/pdf,image/*" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                  <i className="fa-solid fa-file-pdf text-3xl text-slate-300 group-hover:text-indigo-400 transition-colors mb-2"></i>
                  <p className="text-slate-600 font-medium text-sm">Upload 990s and State Profiles</p>
                </div>
                {files.length > 0 && (
                  <div className="mt-4 space-y-2">
                    {files.map((f, i) => (
                      <div key={i} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-100">
                        <div className="flex items-center gap-3 overflow-hidden">
                          <i className="fa-solid fa-file-lines text-indigo-500 text-xs"></i>
                          <span className="text-xs text-slate-700 truncate font-medium">{f.name}</span>
                        </div>
                        <button
                          onClick={() => setFiles(files.filter((_, idx) => idx !== i))}
                          className="text-slate-400 hover:text-red-500 transition-colors p-1"
                          aria-label={`Remove file ${f.name}`}
                          title={`Remove ${f.name}`}
                        >
                          <i className="fa-solid fa-xmark text-xs" aria-hidden="true"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2 text-slate-700">
                  <i className="fa-solid fa-award text-indigo-500"></i>
                  Quality & Compliance Report
                </h2>
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-6 text-center hover:border-indigo-400 transition-colors group relative bg-indigo-50/30">
                  <input type="file" accept="application/pdf,image/*" onChange={handleQualityFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                  <i className="fa-solid fa-clipboard-check text-3xl text-indigo-300 group-hover:text-indigo-500 transition-colors mb-2"></i>
                  <p className="text-slate-600 font-medium text-sm">
                    {qualityFile ? qualityFile.name : "Upload Quality Report PDF (QSR)"}
                  </p>
                  {qualityFile && (
                    <button 
                      onClick={(e) => { e.stopPropagation(); setQualityFile(null); }} 
                      className="mt-2 text-[10px] font-bold text-red-500 hover:underline uppercase tracking-widest"
                    >
                      Remove and Change
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-2 font-medium">This file is used to generate the Performance Scorecard.</p>
              </section>

              {error && (
                <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm flex items-start gap-3">
                  <i className="fa-solid fa-circle-exclamation mt-0.5"></i>
                  <p>{error}</p>
                </div>
              )}
            </div>

            <div className="space-y-6">
              <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2 text-slate-700">
                  <i className="fa-solid fa-globe text-indigo-500"></i>
                  Web Research & Context
                </h2>
                <div className="space-y-6">
                  <div>
                    <label htmlFor="website-url" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Website URL</label>
                    <input
                      id="website-url"
                      type="url"
                      placeholder="https://organization.org"
                      className={`w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-indigo-500 outline-none text-sm ${
                        urlError ? 'border-red-300 bg-red-50' : 'border-slate-200'
                      }`}
                      value={websiteUrl}
                      onChange={handleUrlChange}
                      aria-invalid={!!urlError}
                      aria-describedby={urlError ? 'url-error' : undefined}
                    />
                    {urlError && (
                      <p id="url-error" className="mt-2 text-xs text-red-600 flex items-center gap-1">
                        <i className="fa-solid fa-circle-exclamation" aria-hidden="true"></i>
                        {urlError}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${deepResearch ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-400'}`}>
                        <i className="fa-solid fa-bolt"></i>
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-700">Deep Research Mode</h4>
                        <p className="text-[10px] text-slate-500">AI will scour the web for news, sentiment, and reputation.</p>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" checked={deepResearch} onChange={(e) => setDeepResearch(e.target.checked)} />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>
                </div>
              </section>

              <button
                onClick={runAnalysis}
                disabled={files.length === 0 || !apiKey || !!urlError}
                className={`w-full py-4 rounded-xl text-white font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all ${
                  files.length === 0 || !apiKey || !!urlError ? 'bg-slate-300 cursor-not-allowed' : 'bg-slate-900 hover:bg-slate-800'
                }`}
                aria-label={!apiKey ? 'API key required - click gear icon to configure' : 'Generate executive dossier'}
              >
                <i className="fa-solid fa-microscope" aria-hidden="true"></i>
                Generate Executive Dossier
              </button>
              {!apiKey && (
                <p className="text-center text-xs text-amber-600 mt-2 flex items-center justify-center gap-1">
                  <i className="fa-solid fa-exclamation-triangle" aria-hidden="true"></i>
                  API key required. Click the <i className="fa-solid fa-gear mx-1" aria-hidden="true"></i> icon to configure.
                </p>
              )}
            </div>
          </div>
        ) : status === AnalysisStatus.ANALYZING ? (
          <div className="min-h-[60vh] flex flex-col items-center justify-center text-center animate-in zoom-in duration-300">
            <div className="relative">
              <div className="w-32 h-32 border-8 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                 <i className="fa-solid fa-brain text-indigo-600 text-2xl animate-pulse"></i>
              </div>
            </div>
            <h2 className="text-2xl font-bold mt-8 text-slate-800 tracking-tight">Intelligence Gathering in Progress...</h2>
            <div className="mt-6 max-w-sm space-y-3 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 text-sm text-slate-500 animate-pulse">
                <i className="fa-solid fa-check text-emerald-500"></i>
                <span>Parsing Tax Documents (Form 990)</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-500 animate-pulse delay-150">
                <i className="fa-solid fa-search text-indigo-500"></i>
                <span>Deep Search: Fetching News & Sentiment</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-500 animate-pulse delay-300">
                <i className="fa-solid fa-calculator text-slate-400"></i>
                <span>Calculating 5-Year Financial History</span>
              </div>
            </div>
          </div>
        ) : result ? (
          <AnalysisDisplay result={result} onSave={() => saveLead(result)} />
        ) : null}
      </main>
    </div>
  );
};

export default App;
